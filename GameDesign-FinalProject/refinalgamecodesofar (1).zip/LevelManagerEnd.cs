﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelManagerEnd : MonoBehaviour
{
    public void LoadLevel(string level)
    {
        SceneManager.LoadScene("Start");
        Debug.Log("Attempting to load " + level);
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LoadZone : MonoBehaviour
{
    public LevelManager levelManager;
    public void OnCollisionEnter2D(Collision2D Player)
    {
        print("Attempting to Load Victory");
        levelManager.LoadLevel("Victory");
    }


}
